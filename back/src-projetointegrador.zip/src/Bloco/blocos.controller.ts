import { BlocosService } from './blocos.service';
<<<<<<< HEAD
import { Body, Controller, Post } from '@nestjs/common';
=======
import { Body, Controller, Get, Post } from '@nestjs/common';
>>>>>>> origin/back
import { CreateBlocos } from './dto/criar-bloco.dto';

@Controller('blocos')
export class BlocosController {
  constructor(private readonly blocosService: BlocosService) {}

  @Post()
  criar(@Body() body: CreateBlocos) {
    return this.blocosService.criarBloco(body);
  }
<<<<<<< HEAD
=======
  @Get()
  listar() {
    return this.blocosService.listas();
  }
>>>>>>> origin/back
}
